function lockedProfile() {
    const mainElement = document.getElementById('main');
    const url = 'http://localhost:3030/jsonstore/advanced/profiles';

    fetch(url).then(response => {
        if (response.status != 200) {
            throw new Error();
        }
        return response.json();
    }).then(data => {
        const profiles = Object.values(data);

        profiles.forEach(user => {
            const divElement = document.createElement('div');
            const button = document.createElement('button');
            
            divElement.className = 'profile';
            button.textContent = 'Show more';

            button.addEventListener('click',onclick);

            divElement.innerHTML = `<img src="./iconProfile2.png" class="userIcon" />
            <label>Lock</label>
            <input type="radio" name="user1Locked" value="lock" checked>
            <label>Unlock</label>
            <input type="radio" name="user1Locked" value="unlock"><br>
            <hr>
            <label>Username</label>
            <input type="text" name="user1Username" value="${user.username}" disabled readonly />
            <div class="user1Username" style="display: none;">
                <hr>
                <label>Email:</label>
                <input type="email" name="user1Email" value="${user.email}" disabled readonly />
                <label>Age:</label>
                <input type="text" name="user1Age" value="${user.age}" disabled readonly />
            </div>`

            divElement.appendChild(button);
            mainElement.appendChild(divElement);
        })
    }).catch(err => {
        mainElement.textContent = err;
    })

    function onclick(ev) {
        if(ev.target.parentElement.querySelector('input[value="unlock"]').checked) {
            if(ev.target.parentElement.querySelector('.user1Username').style.display == 'none') {
                ev.target.parentElement.querySelector('.user1Username').style.display = 'block';
                ev.target.textContent = 'Hide it';
            }else if(ev.target.parentElement.querySelector('.user1Username').style.display == 'block') {
                ev.target.parentElement.querySelector('.user1Username').style.display = 'none';
                ev.target.textContent = 'Show more';
            } 
        }
    }
}