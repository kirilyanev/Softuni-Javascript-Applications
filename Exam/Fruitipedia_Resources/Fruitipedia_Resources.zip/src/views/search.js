import { html } from '../../node_modules/lit-html/lit-html.js';
import { searchFruit } from '../data/fruits.js';
import { createSubmitHandler } from '../data/util.js';

const searchTemplate = (onSearch, list) => html`
    <section id="search">
    
        <div class="form">
            <h2>Search</h2>
            <form class="search-form" @submit=${onSearch}>
                <input type="text" name="search" id="search-input" />
                <button class="button-list">Search</button>
            </form>
        </div>
        <h4>Results:</h4>
        <div class="search-result">
            ${html`${Object.values(list).map(fruitCard)}`}
            ${html`<p class="no-result">No result.</p>`}
    
        </div>
    </section>`;

const fruitCard = (fruit) => html`
<div class="fruit">
    <img src="./images/fruit 1.png" alt="example1" />
    <h3 class="title">${fruit.name}</h3>
    <p class="description">${fruit.description}</p>
    <a class="details-btn" href="/dashboard/${fruit._id}">More Info</a>
</div>`;


export function searchPage(ctx) {
    let list = {};
    async function onSearch(query, form) {

        let list = await searchFruit(query.search);
        ctx.page.redirect('/search?search=' + query.search);
    }

    ctx.render(searchTemplate(createSubmitHandler(onSearch), list));
}