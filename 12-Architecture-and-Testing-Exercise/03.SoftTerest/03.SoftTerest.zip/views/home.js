const section = document.getElementById('homeView');

export function showHomeView(ctx) {
    ctx.showSection(section);
}